CREATE TABLE IF NOT EXISTS rooms (
  id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  platform_room_id TEXT NOT NULL UNIQUE,
  title TEXT,
  streamer_name TEXT,
  category TEXT,
  is_live BOOLEAN,
  last_seen_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS users (
  id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  platform_uid TEXT UNIQUE,
  nickname TEXT,
  platform_level INTEGER,
  first_seen_at TIMESTAMPTZ,
  last_seen_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS stream_sessions (
  id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  room_id BIGINT NOT NULL REFERENCES rooms(id),
  started_at TIMESTAMPTZ,
  ended_at TIMESTAMPTZ,
  source TEXT NOT NULL DEFAULT 'live_capture',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS danmu_events (
  id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  event_key TEXT UNIQUE,
  room_id BIGINT NOT NULL REFERENCES rooms(id),
  session_id BIGINT REFERENCES stream_sessions(id),
  user_id BIGINT REFERENCES users(id),
  content TEXT NOT NULL,
  event_time TIMESTAMPTZ,
  received_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  source_type TEXT NOT NULL DEFAULT 'live',
  raw_event JSONB
);
CREATE INDEX IF NOT EXISTS idx_danmu_room_time ON danmu_events(room_id, event_time DESC);
CREATE INDEX IF NOT EXISTS idx_danmu_user_time ON danmu_events(user_id, event_time DESC);
CREATE INDEX IF NOT EXISTS idx_danmu_content_fts ON danmu_events USING GIN(to_tsvector('simple', content));
CREATE INDEX IF NOT EXISTS idx_danmu_event_time ON danmu_events(event_time DESC);
CREATE TABLE IF NOT EXISTS gift_catalog (
  id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  platform_gift_id TEXT UNIQUE,
  name TEXT NOT NULL UNIQUE,
  unit_value NUMERIC(18,4),
  value_unit TEXT,
  value_source TEXT,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS gift_events (
  id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  event_key TEXT UNIQUE,
  room_id BIGINT NOT NULL REFERENCES rooms(id),
  session_id BIGINT REFERENCES stream_sessions(id),
  user_id BIGINT REFERENCES users(id),
  gift_id BIGINT REFERENCES gift_catalog(id),
  quantity BIGINT NOT NULL DEFAULT 1,
  event_time TIMESTAMPTZ,
  received_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  gift_price NUMERIC(18,4),
  gift_earn NUMERIC(18,4),
  raw_event JSONB
);
CREATE INDEX IF NOT EXISTS idx_gift_room_time ON gift_events(room_id, event_time DESC);
CREATE INDEX IF NOT EXISTS idx_gift_user_time ON gift_events(user_id, event_time DESC);
CREATE INDEX IF NOT EXISTS idx_gift_event_time ON gift_events(event_time DESC);
CREATE TABLE IF NOT EXISTS collector_tasks (
  id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  platform_room_id TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  priority INTEGER NOT NULL DEFAULT 100,
  error_count INTEGER NOT NULL DEFAULT 0,
  last_seen_at TIMESTAMPTZ,
  last_error TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

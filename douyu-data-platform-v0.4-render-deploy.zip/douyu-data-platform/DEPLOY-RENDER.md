# Render 公网测试部署

本项目带有 `render.yaml`，可在 Render 通过 Blueprint 创建前端、API、斗鱼采集器和 PostgreSQL。网页由 Nginx 反代 API 与 WebSocket，部署完成后会获得 `https://...onrender.com` 公网入口。

## 重要限制
- 此配置使用 Render Free 资源用于短期测试。免费 Web 服务可能在闲置后休眠，冷启动会有延迟；免费 PostgreSQL 的有效期、容量和可用性以 Render 创建页面当前说明为准，不能当作长期生产数据库。
- Render Free 多服务之间通过公网 HTTPS 通信；采集器控制接口使用随机 `COLLECTOR_TOKEN` 保护，但部署后仍应检查 Logs。
- 斗鱼 WebSocket 客户端协议尚未在 Render 上端到端验证。部署成功只代表网站可访问，不代表真实弹幕或礼物已采集成功。
- 请在创建资源前确认 Render 控制台显示的价格和资源计划；如果控制台显示收费，请不要继续确认，先返回咨询。

## 部署步骤
1. 将项目完整文件放入一个新的 GitHub 仓库（建议 Private），必须包含根目录 `render.yaml`。不要提交 `.env`、令牌或密码。
2. 登录 Render，选择 **New → Blueprint**，授权连接这个 GitHub 仓库。
3. 检查待创建资源及价格；确认是可接受的免费测试资源后再执行 Apply。
4. 等待 `douyu-data-site-fjc-test-1021`、`douyu-api-fjc-test-1021`、`douyu-collector-fjc-test-1021` 和数据库部署完成。
5. 打开 `douyu-data-site-fjc-test-1021` 的 Render `https://...onrender.com` 地址；实时页面路径为 `/realtime.html`。
6. 打开 API 服务域名的 `/api/health`，检查 JSON 中 `database` 为 `ok`。若不是 `ok`，查看 API Logs。
7. 在实时页面输入正在直播的斗鱼房间号并启动采集。只有采集器实际连上斗鱼并接收到事件后，查询页才会出现真实数据。

## 故障排查
- 前端 502/504：检查 API 是否启动成功，及前端的 `API_UPSTREAM` 环境变量。
- API 数据库报错：查看 API Logs，确认数据库已就绪；启动日志会尝试创建 `database/init.sql` 中的表。
- 采集管理返回 401：确认 API 和采集器使用同一环境组里的 `COLLECTOR_TOKEN`。
- 没有弹幕/礼物：查看 collector Logs。斗鱼协议兼容性或礼物事件字段可能仍需修正。

import asyncio
import json
import os
import urllib.request
import urllib.error
from datetime import datetime, timezone
from decimal import Decimal
from typing import Any

import psycopg
from fastapi import FastAPI, Header, HTTPException, Query, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

app = FastAPI(title="Douyu Data Platform API", version="0.3.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=False, allow_methods=["GET", "POST"], allow_headers=["*"])
DATABASE_URL = os.getenv("DATABASE_URL", "")
COLLECTOR_TOKEN = os.getenv("COLLECTOR_TOKEN", "")
COLLECTOR_CONTROL_URL = os.getenv("COLLECTOR_CONTROL_URL", "http://collector:8090")
subscribers: dict[WebSocket, str | None] = {}


def db_connect():
    if not DATABASE_URL:
        raise HTTPException(status_code=503, detail="DATABASE_URL 未配置")
    url = DATABASE_URL.replace("postgresql+psycopg://", "postgresql://", 1)
    return psycopg.connect(url)


def migrate():
    # Initialize missing tables on managed PostgreSQL (e.g. Render) before additive migrations.
    schema_path = os.getenv("SCHEMA_PATH", "/app/init.sql")
    with db_connect() as conn, conn.cursor() as cur:
        if os.path.exists(schema_path):
            schema = open(schema_path, "r", encoding="utf-8").read()
            for statement in schema.split(";"):
                statement = statement.strip()
                if statement:
                    cur.execute(statement)
        # Safe additive migration for installations that already have a persistent DB volume.
        cur.execute("ALTER TABLE gift_events ADD COLUMN IF NOT EXISTS gift_price NUMERIC(18,4)")
        cur.execute("ALTER TABLE gift_events ADD COLUMN IF NOT EXISTS gift_earn NUMERIC(18,4)")
        cur.execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS platform_level INTEGER")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_gift_event_time ON gift_events(event_time DESC)")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_danmu_event_time ON danmu_events(event_time DESC)")


@app.on_event("startup")
def startup_migrate():
    try:
        migrate()
    except Exception as exc:
        # Keep API bootable so /health reports the service while DB diagnostics remain visible.
        print(f"database migration pending: {type(exc).__name__}: {exc}")


class LiveEvent(BaseModel):
    room_id: str = Field(min_length=1, max_length=30)
    type: str
    event_id: str | None = None
    event_time: datetime | None = None
    user_id: str | None = None
    nickname: str = "未知用户"
    user_level: int | None = None
    content: str = ""
    gift_name: str | None = None
    quantity: int = 1
    gift_price: float | None = None
    gift_earn: float | None = None
    raw_event: dict[str, Any] = Field(default_factory=dict)


@app.get("/api/health")
def health():
    db = "ok"
    try:
        with db_connect() as conn, conn.cursor() as cur:
            cur.execute("SELECT 1")
    except Exception as exc:
        db = f"error:{type(exc).__name__}"
    return {"status": "ok" if db == "ok" else "degraded", "database": db, "service": "douyu-data-platform-api", "version": "0.3.0", "time": datetime.now(timezone.utc).isoformat()}


@app.get("/api/overview")
def overview():
    try:
        with db_connect() as conn, conn.cursor() as cur:
            cur.execute("SELECT count(*), count(*) FILTER (WHERE is_live IS TRUE) FROM rooms")
            rooms, live_rooms = cur.fetchone()
            cur.execute("SELECT count(*) FROM danmu_events WHERE received_at >= date_trunc('day', now())")
            danmu_today = cur.fetchone()[0]
            cur.execute("SELECT count(*), COALESCE(sum(quantity),0), COALESCE(sum(gift_earn),0) FROM gift_events WHERE received_at >= date_trunc('day', now())")
            gift_events_today, gift_count_today, gift_earn_today = cur.fetchone()
            cur.execute("SELECT count(*) FROM users")
            users = cur.fetchone()[0]
            cur.execute("SELECT count(*) FROM danmu_events WHERE received_at >= now() - interval '5 minutes'")
            danmu_5m = cur.fetchone()[0]
        return {"mode": "database", "rooms": rooms, "live_rooms": live_rooms, "users": users, "danmu_events_today": danmu_today, "danmu_events_5m": danmu_5m, "gift_events_today": gift_events_today, "gift_count_today": gift_count_today, "gift_earn_today": float(gift_earn_today or 0), "connected_to_douyu": None}
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"总览查询失败: {type(exc).__name__}: {exc}")


def build_where(conditions: list[str]) -> str:
    return " WHERE " + " AND ".join(conditions) if conditions else ""


def page_args(page: int, page_size: int):
    return max(1, page), min(max(1, page_size), 200)


@app.get("/api/rooms")
def rooms(q: str | None = None, is_live: bool | None = None, page: int = 1, page_size: int = 50):
    page, page_size = page_args(page, page_size)
    cond, args = [], []
    if q:
        cond.append("(r.platform_room_id ILIKE %s OR COALESCE(r.streamer_name,'') ILIKE %s OR COALESCE(r.title,'') ILIKE %s)")
        args += [f"%{q}%"] * 3
    if is_live is not None:
        cond.append("r.is_live = %s"); args.append(is_live)
    where = build_where(cond)
    try:
        with db_connect() as conn, conn.cursor() as cur:
            cur.execute(f"SELECT count(*) FROM rooms r{where}", args); total = cur.fetchone()[0]
            cur.execute(f"SELECT r.platform_room_id,r.title,r.streamer_name,r.category,r.is_live,r.last_seen_at,r.updated_at, (SELECT count(*) FROM danmu_events d WHERE d.room_id=r.id) danmu_count, (SELECT count(*) FROM gift_events g WHERE g.room_id=r.id) gift_count FROM rooms r{where} ORDER BY r.updated_at DESC NULLS LAST LIMIT %s OFFSET %s", args + [page_size, (page-1)*page_size])
            items = [dict(room_id=r[0], title=r[1], streamer_name=r[2], category=r[3], is_live=r[4], last_seen_at=r[5].isoformat() if r[5] else None, updated_at=r[6].isoformat() if r[6] else None, danmu_count=r[7], gift_count=r[8]) for r in cur.fetchall()]
        return {"items": items, "page": page, "page_size": page_size, "total": total, "mode": "database"}
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"房间查询失败: {type(exc).__name__}: {exc}")


def event_filters(room_id, user_id, keyword, start_time, end_time, conditions, args, alias="d"):
    if room_id: conditions.append("r.platform_room_id = %s"); args.append(room_id)
    if user_id: conditions.append("u.platform_uid = %s"); args.append(user_id)
    if keyword: conditions.append(f"{alias}.content ILIKE %s"); args.append(f"%{keyword}%")
    if start_time: conditions.append(f"{alias}.event_time >= %s"); args.append(start_time)
    if end_time: conditions.append(f"{alias}.event_time < %s"); args.append(end_time)


@app.get("/api/danmu")
def danmu(room_id: str | None = None, user_id: str | None = None, keyword: str | None = None, start_time: datetime | None = None, end_time: datetime | None = None, page: int = 1, page_size: int = 50):
    page, page_size = page_args(page, page_size)
    conditions, args = [], []
    event_filters(room_id, user_id, keyword, start_time, end_time, conditions, args)
    where = build_where(conditions)
    try:
        with db_connect() as conn, conn.cursor() as cur:
            cur.execute(f"SELECT count(*) FROM danmu_events d JOIN rooms r ON r.id=d.room_id LEFT JOIN users u ON u.id=d.user_id{where}", args); total = cur.fetchone()[0]
            cur.execute(f"SELECT d.id,d.event_time,d.received_at,r.platform_room_id,u.nickname,u.platform_uid,u.platform_level,d.content,d.source_type FROM danmu_events d JOIN rooms r ON r.id=d.room_id LEFT JOIN users u ON u.id=d.user_id{where} ORDER BY d.event_time DESC NULLS LAST,d.id DESC LIMIT %s OFFSET %s", args + [page_size, (page-1)*page_size])
            items = [dict(id=r[0], event_time=(r[1] or r[2]).isoformat(), room_id=r[3], nickname=r[4] or "未知用户", user_id=r[5], user_level=r[6], content=r[7], source_type=r[8]) for r in cur.fetchall()]
        return {"items": items, "page": page, "page_size": page_size, "total": total, "mode": "database"}
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"弹幕查询失败: {type(exc).__name__}: {exc}")


@app.get("/api/gifts")
def gifts(room_id: str | None = None, user_id: str | None = None, keyword: str | None = None, start_time: datetime | None = None, end_time: datetime | None = None, page: int = 1, page_size: int = 50):
    page, page_size = page_args(page, page_size)
    cond, args = [], []
    if room_id: cond.append("r.platform_room_id=%s"); args.append(room_id)
    if user_id: cond.append("u.platform_uid=%s"); args.append(user_id)
    if keyword: cond.append("(gc.name ILIKE %s OR COALESCE(u.nickname,'') ILIKE %s)"); args += [f"%{keyword}%", f"%{keyword}%"]
    if start_time: cond.append("g.event_time >= %s"); args.append(start_time)
    if end_time: cond.append("g.event_time < %s"); args.append(end_time)
    where = build_where(cond)
    try:
        with db_connect() as conn, conn.cursor() as cur:
            base = " FROM gift_events g JOIN rooms r ON r.id=g.room_id LEFT JOIN users u ON u.id=g.user_id LEFT JOIN gift_catalog gc ON gc.id=g.gift_id"
            cur.execute(f"SELECT count(*){base}{where}", args); total = cur.fetchone()[0]
            cur.execute(f"SELECT g.id,g.event_time,g.received_at,r.platform_room_id,u.nickname,u.platform_uid,gc.name,g.quantity,g.gift_price,g.gift_earn{base}{where} ORDER BY g.event_time DESC NULLS LAST,g.id DESC LIMIT %s OFFSET %s", args + [page_size, (page-1)*page_size])
            items = [dict(id=r[0], event_time=(r[1] or r[2]).isoformat(), room_id=r[3], nickname=r[4] or "未知用户", user_id=r[5], gift_name=r[6] or "未知礼物", quantity=r[7], gift_price=float(r[8]) if r[8] is not None else None, gift_earn=float(r[9]) if r[9] is not None else None) for r in cur.fetchall()]
            cur.execute(f"SELECT count(*),COALESCE(sum(g.quantity),0),COALESCE(sum(g.gift_earn),0){base}{where}", args)
            stats = cur.fetchone()
        return {"items": items, "page": page, "page_size": page_size, "total": total, "stats": {"events": stats[0], "quantity": int(stats[1]), "earn": float(stats[2])}, "mode": "database"}
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"礼物查询失败: {type(exc).__name__}: {exc}")


@app.get("/api/users")
def users(q: str | None = None, room_id: str | None = None, page: int = 1, page_size: int = 50):
    page, page_size = page_args(page, page_size)
    cond, args = [], []
    if q: cond.append("(COALESCE(u.nickname,'') ILIKE %s OR COALESCE(u.platform_uid,'') ILIKE %s)"); args += [f"%{q}%", f"%{q}%"]
    if room_id: cond.append("(EXISTS (SELECT 1 FROM danmu_events dx JOIN rooms rx ON rx.id=dx.room_id WHERE dx.user_id=u.id AND rx.platform_room_id=%s) OR EXISTS (SELECT 1 FROM gift_events gx JOIN rooms rg ON rg.id=gx.room_id WHERE gx.user_id=u.id AND rg.platform_room_id=%s))"); args += [room_id, room_id]
    where = build_where(cond)
    try:
        with db_connect() as conn, conn.cursor() as cur:
            cur.execute(f"SELECT count(*) FROM users u{where}", args); total = cur.fetchone()[0]
            cur.execute(f"SELECT u.platform_uid,u.nickname,u.platform_level,u.first_seen_at,u.last_seen_at,(SELECT count(*) FROM danmu_events d WHERE d.user_id=u.id) danmu_count,(SELECT count(*) FROM gift_events g WHERE g.user_id=u.id) gift_events,(SELECT COALESCE(sum(g.quantity),0) FROM gift_events g WHERE g.user_id=u.id) gifts_sent FROM users u{where} ORDER BY u.last_seen_at DESC NULLS LAST LIMIT %s OFFSET %s", args + [page_size, (page-1)*page_size])
            items = [dict(user_id=r[0], nickname=r[1] or "未知用户", level=r[2], first_seen_at=r[3].isoformat() if r[3] else None, last_seen_at=r[4].isoformat() if r[4] else None, danmu_count=r[5], gift_events=r[6], gifts_sent=int(r[7])) for r in cur.fetchall()]
        return {"items": items, "page": page, "page_size": page_size, "total": total, "mode": "database"}
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"用户查询失败: {type(exc).__name__}: {exc}")


@app.post("/api/ingest/event")
async def ingest_event(event: LiveEvent, x_collector_token: str | None = Header(default=None)):
    if not COLLECTOR_TOKEN or x_collector_token != COLLECTOR_TOKEN:
        raise HTTPException(status_code=401, detail="采集器身份验证失败")
    if event.type not in {"chat", "gift", "yuwan", "deserve", "dgb", "gdp", "bc_buy_deserve", "spbc", "ssd", "anbc", "tsgs", "tsboxb"}:
        raise HTTPException(status_code=400, detail="不支持的事件类型")
    now = datetime.now(timezone.utc)
    event_time = event.event_time or now
    event_key = f"{event.room_id}:{event.type}:{event.event_id}" if event.event_id else None
    try:
        with db_connect() as conn, conn.cursor() as cur:
            cur.execute("INSERT INTO rooms(platform_room_id,last_seen_at,updated_at) VALUES(%s,%s,%s) ON CONFLICT(platform_room_id) DO UPDATE SET last_seen_at=EXCLUDED.last_seen_at,updated_at=EXCLUDED.updated_at RETURNING id", (event.room_id, now, now))
            room_pk = cur.fetchone()[0]
            user_pk = None
            if event.user_id:
                cur.execute("INSERT INTO users(platform_uid,nickname,platform_level,first_seen_at,last_seen_at) VALUES(%s,%s,%s,%s,%s) ON CONFLICT(platform_uid) DO UPDATE SET nickname=EXCLUDED.nickname,platform_level=COALESCE(EXCLUDED.platform_level,users.platform_level),last_seen_at=EXCLUDED.last_seen_at RETURNING id", (event.user_id, event.nickname, event.user_level, now, now))
                user_pk = cur.fetchone()[0]
            is_gift = event.type != "chat"
            if not is_gift:
                cur.execute("INSERT INTO danmu_events(event_key,room_id,user_id,content,event_time,received_at,source_type,raw_event) VALUES(%s,%s,%s,%s,%s,%s,'live',%s) ON CONFLICT(event_key) DO NOTHING", (event_key, room_pk, user_pk, event.content, event_time, now, json.dumps(event.raw_event, ensure_ascii=False)))
            else:
                gift_name = event.gift_name or event.content or event.type
                cur.execute("INSERT INTO gift_catalog(name,value_unit,value_source) VALUES(%s,'unknown','collector_event') ON CONFLICT(name) DO UPDATE SET updated_at=now() RETURNING id", (gift_name,))
                gift_pk = cur.fetchone()[0]
                cur.execute("INSERT INTO gift_events(event_key,room_id,user_id,gift_id,quantity,event_time,received_at,gift_price,gift_earn,raw_event) VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s) ON CONFLICT(event_key) DO NOTHING", (event_key, room_pk, user_pk, gift_pk, max(event.quantity, 1), event_time, now, event.gift_price, event.gift_earn, json.dumps(event.raw_event, ensure_ascii=False)))
        payload = {"room_id": event.room_id, "type": event.type, "event_id": event.event_id, "event_time": event_time.isoformat(), "user_id": event.user_id, "nickname": event.nickname, "content": event.content, "gift_name": event.gift_name, "quantity": event.quantity, "gift_price": event.gift_price, "gift_earn": event.gift_earn, "user_level": event.user_level, "received_at": now.isoformat()}
        stale = []
        for ws, room_filter in list(subscribers.items()):
            if room_filter and room_filter != event.room_id:
                continue
            try:
                await ws.send_json(payload)
            except Exception:
                stale.append(ws)
        for ws in stale: subscribers.pop(ws, None)
        return {"accepted": True, "event": payload}
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"事件保存失败: {type(exc).__name__}: {exc}")


def collector_request(path: str, method: str = "GET"):
    if not COLLECTOR_TOKEN: raise HTTPException(status_code=503, detail="COLLECTOR_TOKEN 未配置")
    req = urllib.request.Request(COLLECTOR_CONTROL_URL + path, method=method, data=b"{}" if method == "POST" else None, headers={"x-collector-token": COLLECTOR_TOKEN, "content-type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=8) as response: return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc: raise HTTPException(status_code=exc.code, detail=exc.read().decode("utf-8", errors="replace"))
    except Exception as exc: raise HTTPException(status_code=503, detail=f"采集器暂不可用: {type(exc).__name__}: {exc}")


@app.get("/api/collector/status")
def collector_status(): return collector_request("/rooms")


@app.post("/api/collector/rooms/{room_id}/start")
def start_collector(room_id: str):
    if not room_id.isdigit() or len(room_id) > 20: raise HTTPException(status_code=400, detail="请输入有效的数字房间号")
    try:
        now = datetime.now(timezone.utc)
        with db_connect() as conn, conn.cursor() as cur:
            cur.execute("INSERT INTO rooms(platform_room_id,last_seen_at,updated_at) VALUES(%s,%s,%s) ON CONFLICT(platform_room_id) DO UPDATE SET updated_at=EXCLUDED.updated_at", (room_id, now, now))
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"无法登记房间到数据库: {type(exc).__name__}: {exc}")
    return collector_request(f"/rooms/{room_id}/start", "POST")


@app.post("/api/collector/rooms/{room_id}/stop")
def stop_collector(room_id: str):
    if not room_id.isdigit() or len(room_id) > 20: raise HTTPException(status_code=400, detail="无效房间号")
    return collector_request(f"/rooms/{room_id}/stop", "POST")


@app.websocket("/ws/live")
async def live_socket(websocket: WebSocket, room_id: str | None = Query(default=None)):
    await websocket.accept(); subscribers[websocket] = room_id
    try:
        await websocket.send_json({"type": "system", "content": "实时通道已连接；只有真实采集器收到事件后才会显示数据。", "room_id": room_id})
        while True: await websocket.receive_text()
    except WebSocketDisconnect: subscribers.pop(websocket, None)
    except Exception: subscribers.pop(websocket, None)

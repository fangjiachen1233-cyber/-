const express = require('express');
const { Client } = require('douyudm');

const app = express();
app.use(express.json({ limit: '256kb' }));
const PORT = Number(process.env.PORT || 8090);
const API_URL = process.env.API_URL || 'http://api:8000';
const TOKEN = process.env.COLLECTOR_TOKEN || '';
const clients = new Map();

function authorized(req, res, next) {
  if (!TOKEN || req.header('x-collector-token') !== TOKEN) return res.status(401).json({ error: 'unauthorized' });
  next();
}
function first(obj, keys, fallback = null) {
  for (const key of keys) if (obj && obj[key] !== undefined && obj[key] !== null && obj[key] !== '') return obj[key];
  return fallback;
}
function postEvent(roomId, type, msg) {
  const gift = type !== 'chat';
  const nickname = String(first(msg, ['nn', 'sn', 'nickname', 'name'], '未知用户'));
  const userId = first(msg, ['uid', 'rid', 'user_id', 'did']);
  const eventId = first(msg, ['id', 'seq']);
  const eventTimeRaw = first(msg, ['time', 'ts']);
  let eventTime = new Date().toISOString();
  if (eventTimeRaw !== null) {
    const n = Number(eventTimeRaw);
    if (Number.isFinite(n)) eventTime = new Date(n < 1e12 ? n * 1000 : n).toISOString();
  }
  const giftName = String(first(msg, ['gfn', 'gn', 'gfname', 'giftname', 'gift_name', 'name', 'rpt'], type));
  const count = Number(first(msg, ['gfcnt', 'gc', 'count', 'hits', 'quantity'], 1));
  const price = first(msg, ['price', 'gfcnt_price', 'gift_price']);
  const earn = first(msg, ['earn', 'gift_earn']);
  const event = {
    room_id: String(roomId), type: gift ? type : 'chat',
    event_id: eventId == null ? `${type}:${userId || 'unknown'}:${eventTime}:${JSON.stringify(msg).slice(0,100)}` : String(eventId),
    event_time: eventTime, user_id: userId == null ? null : String(userId), nickname,
    user_level: Number.isFinite(Number(first(msg, ['level', 'level_int']))) ? Number(first(msg, ['level', 'level_int'])) : null,
    content: gift ? giftName : String(first(msg, ['txt', 'content', 'text'], '')),
    gift_name: gift ? giftName : null,
    quantity: Number.isFinite(count) && count > 0 ? Math.floor(count) : 1,
    gift_price: price == null || !Number.isFinite(Number(price)) ? null : Number(price),
    gift_earn: earn == null || !Number.isFinite(Number(earn)) ? null : Number(earn),
    raw_event: { event_type: type, ...msg }
  };
  fetch(`${API_URL}/api/ingest/event`, {
    method: 'POST', headers: { 'content-type': 'application/json', 'x-collector-token': TOKEN }, body: JSON.stringify(event)
  }).then(async r => { if (!r.ok) console.error(`[${roomId}] API ingest failed ${r.status}: ${await r.text()}`); })
    .catch(err => console.error(`[${roomId}] API unavailable:`, err.message));
}
function stopRoom(roomId) {
  const record = clients.get(roomId);
  if (!record) return false;
  record.status = 'stopping';
  if (record.retryTimer) clearTimeout(record.retryTimer);
  try {
    if (typeof record.client.stop === 'function') record.client.stop();
    else if (typeof record.client.close === 'function') record.client.close();
  } catch (err) { console.error(`[${roomId}] stop failed: ${err.message}`); }
  clients.delete(roomId);
  return true;
}
app.get('/health', (_, res) => res.json({ status: 'ok', active_rooms: [...clients.keys()] }));
app.get('/rooms', authorized, (_, res) => res.json({ rooms: [...clients.entries()].map(([room_id, c]) => ({ room_id, status: c.status, started_at: c.started_at, last_event_at: c.last_event_at, last_error: c.last_error || null })) }));
app.post('/rooms/:roomId/start', authorized, (req, res) => {
  const roomId = String(req.params.roomId || '').trim();
  if (!/^\d{1,20}$/.test(roomId)) return res.status(400).json({ error: 'room_id must be numeric' });
  if (clients.has(roomId)) return res.json({ room_id: roomId, status: clients.get(roomId).status, already_running: true });
  let client;
  try { client = new Client(roomId, { retries: 5, retryDelay: 1000 }); }
  catch (err) { return res.status(502).json({ error: 'collector_init_failed', detail: err.message }); }
  const record = { client, status: 'connecting', started_at: new Date().toISOString(), last_event_at: null, last_error: null };
  clients.set(roomId, record);
  client.on('connect', () => { record.status = 'connected'; console.log(`[${roomId}] connected`); });
  client.on('disconnect', () => {
    console.log(`[${roomId}] disconnected`);
    if (clients.has(roomId) && record.status !== 'stopping') {
      record.status = 'reconnecting';
      if (record.retryTimer) clearTimeout(record.retryTimer);
      record.retryTimer = setTimeout(() => { if (clients.has(roomId) && record.status === 'reconnecting') { try { record.status = 'connecting'; record.client.run(); } catch (err) { record.status = 'error'; record.last_error = err.message; } } }, 3000);
    }
  });
  client.on('error', (...args) => { const err = args.find(x => x instanceof Error) || args[1] || args[0]; record.status = 'error'; record.last_error = String(err && err.message ? err.message : err); console.error(`[${roomId}] ${record.last_error}`); if (clients.has(roomId)) { if (record.retryTimer) clearTimeout(record.retryTimer); record.retryTimer = setTimeout(() => { if (clients.has(roomId) && record.status === 'error') { try { record.status = 'connecting'; record.client.run(); } catch (e) { record.status = 'error'; record.last_error = e.message; } } }, 15000); } });
  const bind = type => client.on(type, msg => { record.last_event_at = new Date().toISOString(); postEvent(roomId, type, msg || {}); });
  ['chatmsg', 'gdp', 'bc_buy_deserve', 'spbc', 'ssd', 'anbc', 'tsgs', 'tsboxb'].forEach(bind);
  try { client.run(); }
  catch (err) { clients.delete(roomId); return res.status(502).json({ error: 'collector_start_failed', detail: err.message }); }
  res.status(202).json({ room_id: roomId, status: 'connecting', note: '已发起连接；请查看状态与采集日志确认真实连接。' });
});
app.post('/rooms/:roomId/stop', authorized, (req, res) => {
  const roomId = String(req.params.roomId);
  if (!stopRoom(roomId)) return res.status(404).json({ error: 'room_not_running' });
  res.json({ room_id: roomId, status: 'stopped' });
});
app.listen(PORT, '0.0.0.0', () => console.log(`collector control API listening on ${PORT}`));

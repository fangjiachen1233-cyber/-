# 斗鱼数据查询平台（实验性开发版）

当前版本保留总览、主播/房间、弹幕查询、礼物查询、用户档案、实时采集和系统状态页面。查询页面连接后端 API 和 PostgreSQL，不再用静态样例数据伪装查询结果。修复说明见 `CHANGELOG-v0.3.md`。

## 启动

1. 安装 Docker Desktop 并启动。
2. 复制 `.env.example` 为 `.env`，将数据库密码和采集器 Token 改成随机长字符串。
3. 在项目根目录运行：

   ```bash
   docker compose --env-file .env -f deploy/docker-compose.yml up --build -d
   ```

4. 打开 `http://127.0.0.1:8080`。
5. 在“实时采集”输入斗鱼房间号，启动后到“系统状态”确认状态为 `connected`，然后再查询弹幕和礼物。

API 文档：`http://127.0.0.1:8000/docs`（API 仅绑定本机地址）。

## 查询与采集边界

- 总览、房间、弹幕、礼物、用户页面均从数据库读取；无数据时显示空结果和错误提示，不使用固定演示记录。
- 只有真实采集到的弹幕和礼物才会入库。礼物价值字段按采集源提供的数据保存；源数据缺失时显示“未知”。
- `douyudm` 开源客户端的公开 API 适配已更新，但当前容器环境仍需进行一次真实房间端到端验证。不能把启动请求返回成功当作已经收到真实数据。
- 只能采集启动之后实际收到的事件，不能凭空查询过去的弹幕；全站房间发现、多房间调度、历史回溯、官方完整礼物价值表尚未实现。
- 该项目目前是单机实验版，部署到公网前还需要登录鉴权、HTTPS、访问限流、数据保留策略和备份。

## 排错

- 页面显示“API 不可用”：检查 `docker compose --env-file .env -f deploy/docker-compose.yml ps`。
- 数据库异常：查看 `docker compose --env-file .env -f deploy/docker-compose.yml logs api db`。
- 采集器连接错误或一直没有事件：查看 `docker compose --env-file .env -f deploy/docker-compose.yml logs collector`，确认房间号正确，并检查当前网络是否允许访问斗鱼 WebSocket。
- 查询失败：打开“系统状态”检查数据库与采集器。`/api/health` 显示数据库状态，`/api/docs` 不存在时请使用上面的 `/docs` 地址。
